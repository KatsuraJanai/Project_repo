function firstButton()
{
	
	let text, wordsLen, count;
	words = ["vtwor","dguv","k","agnnqy"];
	wordsLen = words.length;

	text = "<ul>";
	for (count = 0; count < wordsLen; count++) 
	{
		text += "<li>" + words[count] + "</li>";
	}
	text += "</ul>";

	document.getElementById("buttonOne").innerHTML = text;
	
}


function secondButton()
{
	
	let text, wordsLen, count;
	words = ["og","dktf","jcemgf","ygctu"];
	wordsLen = words.length;

	text = "<ul>";
	for (count = 0; count < wordsLen; count++) 
	{
		text += "<li>" + words[count] + "</li>";
	}
	text += "</ul>";

	document.getElementById("buttonTwo").innerHTML = text;
	
}


function thirdButton()
{
	
	let text, wordsLen, count;
	words = ["ku","vjg","aqw","c"];
	wordsLen = words.length;

	text = "<ul>";
	for (count = 0; count < wordsLen; count++) 
	{
		text += "<li>" + words[count] + "</li>";
	}
	text += "</ul>";

	document.getElementById("buttonThree").innerHTML = text;
	
}




function fourthButton()
{
	
	let text, wordsLen, count;
	words = ["vqwrgg","jcemgt","agnnqy","vjcp"];
	wordsLen = words.length;

	text = "<ul>";
	for (count = 0; count < wordsLen; count++) 
	{
		text += "<li>" + words[count] + "</li>";
	}
	text += "</ul>";

	document.getElementById("buttonFour").innerHTML = text;
	
}
